package com.securewebapp.forum;




import javax.persistence.*;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.securewebapp.auth.User;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="Message")

public class Message {	
	
		@Id
		@GeneratedValue(strategy= GenerationType.AUTO)
		private long messageid;
		
		@ManyToOne
		@JoinColumn(name="FK_User_id")
		private User userid;

		@ManyToOne
		@JoinColumn(name="Fk_Post_id")
		private CastingCall postid;
		
		private String message_text;

		public String getMessage_text() {
			return message_text;
		}

		public void setMessage_text(String message_text) {
			this.message_text = message_text;
		}

		public long getMessage_id() {
			return messageid;
		}

		public void setMessage_id(long messageid) {
			this.messageid = messageid;
		}

	
		public User getUserid() {
			return userid;
		}

		public void setUserid(User userid) {
			this.userid = userid;
		}

		public CastingCall getPost_id() {
			return postid;
		}

		public void setPost_id(CastingCall postid) {
			this.postid = postid;
		}
}


