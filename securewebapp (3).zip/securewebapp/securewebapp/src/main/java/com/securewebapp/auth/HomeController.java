package com.securewebapp.auth;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.securewebapp.forum.CastingCall;
import com.securewebapp.forum.Message;
import com.securewebapp.forum.MessageRepository;
import com.securewebapp.forum.PostsRepository;
import com.securewebapp.image.Image;
import com.securewebapp.image.ImageRepository;


@RestController
public class HomeController {
		
		@Autowired
		private UserRepository userRepository;
 	
	    @Autowired
	    private MySQLUserDetailsService userService;
	    
	    @Autowired
	    private PostsRepository posts;
	    
	    @Autowired
	    private MessageRepository messages;
	    @Autowired
	    private ImageRepository images;
	    
    @GetMapping("/")
    public String getHomePage() {
        return "home";
    }

    @GetMapping("/login")
    public String getLoginPage() {
        return "login";
    }
    
    @GetMapping("/register")
    public String getRegisterPage() {
    	return "register";
    }
   
   
    @PostMapping("/register")
    public String createUser(@RequestParam("firstName") String firstName, @RequestParam("lastName") String lastName, @RequestParam("username") String username, @RequestParam("password") String password, Model model) {
    	User foundUser = userRepository.findByUsername(username);
    	if (foundUser == null) {
    		User newUser = new User();
    		newUser.setFirstName(firstName);
    		newUser.setLastName(lastName);
    		newUser.setUsername(username);
    		newUser.setPassword(password);
    		userService.Save(newUser);
    		return "update_bio";
    	}
    	else {
    		model.addAttribute("exists", true);
    		return "casting_call";
    	}
    }
    	@PutMapping("/update_bio")
    	public String updateUser(@RequestParam("username")String username,@RequestParam("occupation")String occupation, @RequestParam("email")String email, @RequestParam ("bio")String bio, Model model) {
    		User foundUser=userRepository.findByUsername(username);
    		if (foundUser != null) {
    			foundUser.setOccupation(occupation);
    			foundUser.setEmail(email);
    			foundUser.setBio(bio);
    			userService.Save(foundUser);
    			return "CastingCall";
    			}
    		else {
    			model.addAttribute("exists",false);
    			return"register";
    		}
    		
    	}
    	@GetMapping("/image/{user_id}/{isProfilePic}")
    	public Image getImage(@PathVariable("user_id") Long userid,@PathVariable ("isProfilePic") Boolean isProfilePic){
    		Image foundImage = images.findByuseridAndIsProfilePic(userid, isProfilePic==true);
    			return foundImage;
    				
    	}
    	@GetMapping("/images/{user_id}/{image_id}={isProfilePic}")
    		public List<Image> getImages(@PathVariable("user_id")String userid,@PathVariable("image_id")Long imageid, @PathVariable ("isProfilePic")Boolean isProfilePic){
    			List<Image> foundImage=images.findByisProfilePic(isProfilePic==false);
    			return foundImage;
    		}
    		
    	
    	
    	@GetMapping("/casting_calls")
    	public List<CastingCall> getPosts(){
    		List<CastingCall> foundPosts = posts.findAll();
    		return foundPosts;
    	}
    	
    	@GetMapping("/casting_call/{id}")
    	public ResponseEntity <CastingCall> getPost(@PathVariable("id") Long postid){
    		CastingCall foundPost = posts.findById(postid).orElse(null);
    		
    		if(foundPost==null) {
    			return ResponseEntity.notFound().header("Message", "Nothing found with that id").build();
    		}
    		return ResponseEntity.ok(foundPost);
    	
    	}
    	@GetMapping("casting_calls/{state}/{city}")
		public CastingCall getCastingCall(@PathVariable("state")String state,@PathVariable("city")String city){
			CastingCall foundCastingCalls=posts.findAllByStateAndCity(state, city);
			return foundCastingCalls;
		}
		
    	@GetMapping("/casting_call/{id}/messages")
    	public  ResponseEntity <Message> getMessages(Long postid){
    		Message foundMessages=messages.findById(postid).orElse(null);
		if (foundMessages==null) {
			return ResponseEntity.notFound().header("Message", "No posts yet").build();
		}
    	return ResponseEntity.ok(foundMessages);
}
    	@PostMapping("/casting_call")
    	public ResponseEntity<CastingCall> postMessage(@RequestBody CastingCall post){
    		CastingCall createdPost=posts.save(post);
    		return ResponseEntity.ok(createdPost);
    		
    	}
    	@PostMapping("/messages")
    	public ResponseEntity<Message> postMessage(@RequestBody Message message) {
    		Message createdMessage=messages.save(message);
    		return ResponseEntity.ok(createdMessage);
    	}
	}
