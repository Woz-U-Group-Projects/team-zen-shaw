package com.securewebapp.forum;


import org.springframework.data.jpa.repository.JpaRepository;

import com.securewebapp.forum.CastingCall;

public interface PostsRepository extends JpaRepository<CastingCall, Long> {
	
	CastingCall findAllByStateAndCity(String state,String city);
	

	
	
}
