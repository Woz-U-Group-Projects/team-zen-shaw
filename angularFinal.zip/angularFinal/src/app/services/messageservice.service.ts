import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Message } from '../models/message';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class MessageserviceService {

  
  url: string='http://localhost:8080/api/messages';
 
  getMessage(sender:string):Observable<any>{
    return this.http.get(this.url+"/sent/"+ sender)
  }
  getMessages(receiver:string):Observable<any>{
    return this.http.get(this.url+ "/"+ receiver);
  }
  sendMessage(message:Message) : Observable<any>{
    return this.http.post(this.url, message);
  }
  deleteMessage(messageid:number): Observable<Message> {
     return this.http.delete<Message>(this.url+"/"+messageid)
  }
  constructor(private http : HttpClient) { }
}
