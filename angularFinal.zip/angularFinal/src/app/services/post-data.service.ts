import { Injectable } from '@angular/core';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import { CastingCall} from '../models/castingcall';
import { Observable, of} from 'rxjs';
import {User} from '../models/user';

@Injectable({
  providedIn: 'root'
})
export class PostDataService {

  
  url:string='http://localhost:8080/api/casting_calls'
  
  getCastingCalls(): Observable<any>{
    return this.http.get(this.url);
  }
  getCastingCall(id:number):Observable<any>{
    return this.http.get(this.url+ "/"+ id);
  }
  addCastingCall(post:CastingCall) : Observable<any>{
    return this.http.post(this.url, post);

  }
  editCastingCall(post:CastingCall): Observable<any>{
    return this.http.put(this.url+"/"+post.postid, post)
  }

  deleteCastingcall(postid:number):Observable<any>{
    return this.http.delete(this.url + "/"+ postid);
  }
  constructor(private http : HttpClient) { }

}
