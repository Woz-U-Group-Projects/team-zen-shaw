import { Castingcall } from './castingcall';

describe('Castingcall', () => {
  it('should create an instance', () => {
    expect(new Castingcall()).toBeTruthy();
  });
});
