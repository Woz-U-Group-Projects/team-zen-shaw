export class Message {
    messageid:number;
    receiver:string;
    sender:string;
    subject:string;
    message_text:string;
}

