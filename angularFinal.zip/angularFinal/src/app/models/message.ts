export class Message {
    message_text:string;
}

