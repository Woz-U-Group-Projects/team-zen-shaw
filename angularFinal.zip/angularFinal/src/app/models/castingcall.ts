import { logging } from 'protractor';


export class CastingCall {
    username:string;
    postid:number;
    jobName:string;
    jobDescription:string;
    country:string;
    city:string;
    state:string;
    date:string;
}
