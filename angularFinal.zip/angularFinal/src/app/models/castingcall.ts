export class Castingcall {
    jobName:string;
    jobDescription:string;
    country:string;
    city:string;
    state:string;
    date:Date;
}
