export class User {
    firstName:string;
    lastName:string;
    username:string;
    password:string;
    email:string;
    bio:string;
    occupation:string;
    authorities:string;
}
