import { Component, OnInit } from '@angular/core';
import { UserService } from 'src/app/services/user.service';
import { User } from 'src/app/models/user';
import { Router, ActivatedRoute } from '@angular/router';
import { Observable, of } from 'rxjs';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit {
  user: User=new User();
  getUser() {
    this.userService
    .getUser(this.user.username)
  }

  constructor(private http:HttpClient,
    private userService:UserService, 
    private router : Router, 
    private route : ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(param =>{
      this.userService.getUser(param["username"])
      .subscribe(u =>(this.user=u));
  })
  }

}
