import { Component, OnInit } from '@angular/core';
import { MessageserviceService } from 'src/app/services/messageservice.service';
import { Router, ActivatedRoute } from '@angular/router';
import { Message } from 'src/app/models/message';
import {Observable, of} from 'rxjs';

@Component({
  selector: 'app-sent',
  templateUrl: './sent.component.html',
  styleUrls: ['./sent.component.css']
})
export class SentComponent implements OnInit {
  messages: Message = new Message();
  getMessage() {
    this.messageService
    .getMessage(this.messages.sender)
  }

  constructor(private messageService:MessageserviceService,
    private router : Router, 
    private route : ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(param =>{
      this.messageService.getMessage(param["sender"])
      .subscribe(m =>(this.messages=m));
  })
  }
}
