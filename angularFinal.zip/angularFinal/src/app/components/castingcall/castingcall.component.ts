import { Component, OnInit } from '@angular/core';
import {CastingCall} from '../../models/castingcall';
import { HttpHeaders, HttpClient } from '@angular/common/http';
import { PostDataService} from '../../services/post-data.service';
import {Router} from '@angular/router';
import {User} from'../../models/user';
@Component({
  selector: 'app-castingcall',
  templateUrl: './castingcall.component.html',
  styleUrls: ['./castingcall.component.css']
})
export class CastingcallComponent implements OnInit {
 
  newCastingcall : CastingCall = new CastingCall();


addCastingcall(){
  this.postDataService
  .addCastingCall(this.newCastingcall)
  .subscribe( p => this.router.navigate(["list"]));
}
constructor(private postDataService:PostDataService, private router:Router,private http:HttpClient) { }

  ngOnInit() {
  }

}
