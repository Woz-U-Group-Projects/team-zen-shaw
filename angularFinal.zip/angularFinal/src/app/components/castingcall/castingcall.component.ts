import { Component, OnInit } from '@angular/core';
import {Castingcall} from '../../models/castingcall';
import { HttpClient } from 'selenium-webdriver/http';
@Component({
  selector: 'app-castingcall',
  templateUrl: './castingcall.component.html',
  styleUrls: ['./castingcall.component.css']
})
export class CastingcallComponent implements OnInit {
 title:"Pretium";
  constructor() { }

  ngOnInit() {
  }

}
