import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { CastingcallComponent } from './castingcall.component';

describe('CastingcallComponent', () => {
  let component: CastingcallComponent;
  let fixture: ComponentFixture<CastingcallComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ CastingcallComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(CastingcallComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
