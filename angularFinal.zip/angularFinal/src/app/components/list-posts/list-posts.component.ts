import { Component, OnInit } from '@angular/core';
import { CastingCall } from '../../models/castingcall';
import { PostDataService} from '../../services/post-data.service';
import { HttpClient } from '@angular/common/http';
import { Observable,of } from 'rxjs';
@Component({
  selector: 'app-list-posts',
  templateUrl: './list-posts.component.html',
  styleUrls: ['./list-posts.component.css']
})
export class ListPostsComponent implements OnInit {
  posts: Observable <CastingCall[]>;

  getCastingCalls(): void{
    this.posts = this.postDataService.getCastingCalls();
  };

  constructor(private postDataService:PostDataService, private http:HttpClient) { }

  ngOnInit() {
    this.getCastingCalls();
  }

}
