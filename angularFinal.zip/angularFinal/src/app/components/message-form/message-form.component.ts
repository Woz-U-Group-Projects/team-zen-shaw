import { Component, OnInit } from '@angular/core';
import { User } from 'src/app/models/user';
import { Message } from '../../models/message';
import { UserService } from 'src/app/services/user.service';
import { MessageserviceService } from 'src/app/services/messageservice.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-message-form',
  templateUrl: './message-form.component.html',
  styleUrls: ['./message-form.component.css']
})
export class MessageFormComponent implements OnInit {
message : Message= new Message();
sendMessage(){
  this.messageService
  .sendMessage(this.message)
  .subscribe( p => this.router.navigate(["sent", this.message.sender]));
}
constructor(private userService:UserService, private messageService:MessageserviceService, 
  private router:Router) { }

  ngOnInit() {
  }

}
