import { Component, OnInit } from '@angular/core';
import {User } from '../../models/user';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  title : 'Pretium';
  token : string = '';
  user: User = new User();
  error: string;
  base_url: string = "http://localhost:8080/";
  data:any;

  constructor(private http:HttpClient) { }

  ngOnInit() {
  }
  
  onRegister(){
    this.http.post<any>(this.base_url+'api/user/register', {firstName:this.user.firstName, lastName:this.user.lastName, email:this.user.email, username:this.user.username,
      password: this.user.password, bio:this.user.bio, occupation:this.user.occupation},{observe:'response'})
      .subscribe(
        res=>this.token = res.headers.get("Authorization"),
        error=>this.error = "unable to Register you, username already exists."
      );

    }
  }
