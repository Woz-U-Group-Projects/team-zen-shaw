import { Component, OnInit } from '@angular/core';
import {User } from '../../models/user';
import {UserService} from '../../services/user.service';
import {HttpClient, HttpHeaders} from '@angular/common/http';
import {FormsModule} from '@angular/forms';
import {Observable, of} from 'rxjs';
import { ActivatedRoute, Router } from '@angular/router';
@Component({
  selector: 'app-signup',
  templateUrl: './signup.component.html',
  styleUrls: ['./signup.component.css']
})
export class SignupComponent implements OnInit {
  title : 'Pretium';
  token : string = '';
  user: User = new User();
  error: string;
  base_url: string = "http://localhost:8080/api";

  
  constructor(private http:HttpClient, private userService:UserService, private route:ActivatedRoute, private router:Router) { }

  ngOnInit() {
  }
  
  onRegister(){
    this.userService
    .onRegister(this.user)
    .subscribe(p=>this.router.navigate(["castingcall"]));
        
  }

}

