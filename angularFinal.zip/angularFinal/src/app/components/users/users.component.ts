import { Component, OnInit } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { UserService } from 'src/app/services/user.service';
import { Observable, of } from 'rxjs';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-users',
  templateUrl: './users.component.html',
  styleUrls: ['./users.component.css']
})
export class UsersComponent implements OnInit {
users:Observable<User[]>;

  constructor(private http:HttpClient, private userService:UserService) { }
  getUsers(){
    this.users= this.userService.getUsers();
  }
  ngOnInit() {
    this.getUsers();
  }

}
