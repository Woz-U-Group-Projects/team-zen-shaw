import { Component, OnInit } from '@angular/core';
import { CastingCall } from 'src/app/models/castingcall';
import { PostDataService } from 'src/app/services/post-data.service';
import { Router, ActivatedRoute } from '@angular/router';
import { User } from 'src/app/models/user';

@Component({
  selector: 'app-post',
  templateUrl: './post.component.html',
  styleUrls: ['./post.component.css']
})
export class PostComponent implements OnInit {
  post:CastingCall=new CastingCall();
  user:User=new User();
getPost() {
  this.postDataService
    .getCastingCall(this.post.postid)
   
  }
 
  constructor(private postDataService:PostDataService, 
    private router : Router, 
    private route : ActivatedRoute) { }

  ngOnInit() {
    this.route.params.subscribe(param =>{
      this.postDataService.getCastingCall(+param["postid"])
      .subscribe(p =>(this.post=p));
  })
  }
}