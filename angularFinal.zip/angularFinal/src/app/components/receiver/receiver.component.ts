import { Component, OnInit } from '@angular/core';
import { Message } from 'src/app/models/message';
import { Router, ActivatedRoute } from '@angular/router';
import { MessageserviceService } from 'src/app/services/messageservice.service';
import { Observable } from 'rxjs';

@Component({
  selector: 'app-receiver',
  templateUrl: './receiver.component.html',
  styleUrls: ['./receiver.component.css']
})
export class ReceiverComponent implements OnInit {
  messages: Observable<Message[]>;
  
  constructor(private messageService:MessageserviceService,
    private router : Router, 
    private route : ActivatedRoute) { }

  ngOnInit() {
   this.reloadData();
   

  }
  reloadData(){
    this.route.params.subscribe(param =>{
      this.messageService.getMessages(param["receiver"])
      .subscribe(m =>(this.messages=m));
  })
}
  deleteMessages(messageid){
    this.messageService.deleteMessage(messageid)
    .subscribe(
      data=>{
        console.log(data);
        this.reloadData();
      },
      error => console.log(error)
    );
  }
  }

