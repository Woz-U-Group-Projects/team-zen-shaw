import { BrowserModule } from '@angular/platform-browser';
import { NgModule, Injectable } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { FormsModule} from '@angular/forms';
import { HttpClientModule, HttpRequest, HttpHandler, HttpInterceptor, HTTP_INTERCEPTORS} from '@angular/common/http';

import { HomePageComponent } from './components/home-page/home-page.component';
import { SignupComponent } from './components/signup/signup.component';
import { CastingcallComponent } from './components/castingcall/castingcall.component';
import { ListPostsComponent } from './components/list-posts/list-posts.component';
import { UsersComponent } from './components/users/users.component';
import { PostComponent } from './components/post/post.component';
import { UserComponent } from './components/user/user.component';
import { MessageFormComponent } from './components/message-form/message-form.component';
import { SentComponent } from './components/sent/sent.component';
import { NavComponent } from './nav/nav.component';
import { ReceiverComponent } from './components/receiver/receiver.component';



@NgModule({
  declarations: [
    AppComponent,
    HomePageComponent,
    SignupComponent,
    CastingcallComponent,
    ListPostsComponent,
    UsersComponent,
    PostComponent,
    UserComponent,
    MessageFormComponent,
    SentComponent,
    NavComponent,
    ReceiverComponent
  ],
  imports: [
    BrowserModule,
    AppRoutingModule,
    HttpClientModule,
    FormsModule
  ],
  providers: [],
  bootstrap: [AppComponent]
})
export class AppModule{}


