import { NgModule } from '@angular/core';
import {CommonModule} from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import {HomePageComponent} from './components/home-page/home-page.component';
import { SignupComponent } from './components/signup/signup.component';
import { CastingcallComponent } from './components/castingcall/castingcall.component';


const routes: Routes = [
  {
    path:'',
    component: HomePageComponent
  },
  {
    path:'signup',
    component: SignupComponent
  },
  { 
    path:'castingcall',
    component: CastingcallComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes),CommonModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
