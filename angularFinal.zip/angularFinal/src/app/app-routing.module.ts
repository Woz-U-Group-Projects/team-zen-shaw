import { NgModule, Component } from '@angular/core';
import {CommonModule} from '@angular/common';
import { Routes, RouterModule } from '@angular/router';

import {HomePageComponent} from './components/home-page/home-page.component';
import { SignupComponent } from './components/signup/signup.component';
import { CastingcallComponent } from './components/castingcall/castingcall.component';
import { ListPostsComponent } from './components/list-posts/list-posts.component';
import { UsersComponent } from './components/users/users.component';
import { PostComponent } from './components/post/post.component';
import { MessageFormComponent } from './components/message-form/message-form.component';
import { SentComponent } from './components/sent/sent.component';
import { UserComponent } from './components/user/user.component';
import { ReceiverComponent } from './components/receiver/receiver.component';


const routes: Routes = [
  {
    path:'signup',
    component: SignupComponent
  },
  { 
    path:'castingcall',
    component: CastingcallComponent
  },
  {
    path:'list',
    component:ListPostsComponent
  },
  {
    path:'users',
    component:UsersComponent
  },
  {
    path:'post/:postid',
    component:PostComponent
  },
  {
    path:'users/:username',
    component: UserComponent
  },
  {
    path: 'messageform',
    component: MessageFormComponent
  },
  {
    path:"sent/:sender",
    component: SentComponent
  },
  {
    path:"receiver/:receiver",
    component:ReceiverComponent
  }
];

@NgModule({
  imports: [RouterModule.forRoot(routes),CommonModule],
  exports: [RouterModule]
})
export class AppRoutingModule { }
