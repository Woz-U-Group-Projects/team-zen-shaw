package com.securewebapp;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api")
@CrossOrigin("http://localhost:4200")
public class ForumContoller {

    @Autowired
    private UserRepository users;
    
	@Autowired
    private CastingCallRepository posts;
    
    @Autowired
    private MessageRepository messages;
    
    @GetMapping("/users")
    public List<User> getUser() {
    	return users.findAll();

    }
   
    @GetMapping("/users/{username}")
    public User getUsers(@PathVariable ("username") String username){
    	return users.findByUsername(username);
    }

    @PostMapping("/users")
    public void register(@RequestBody User newUser) {
      users.save(newUser);
    }
	
	@GetMapping("/casting_calls")
	public List<CastingCall> getPosts(){
		return posts.findAll();
	}
	@PostMapping("/casting_calls")
	public void postPost(@RequestBody CastingCall newCastingCall) {
	   posts.save(newCastingCall);
	}
	
	@GetMapping("/casting_calls/{postid}")
	public CastingCall getPost(@PathVariable("postid") Long postid){
		return posts.findByPostid(postid);
	
	
	}
	@GetMapping("casting_calls/{state}/{city}")
	public CastingCall getCastingCall(@PathVariable("state")String state,@PathVariable("city")String city){
 		CastingCall foundCastingCalls=posts.findAllByStateAndCity(state, city);
		return foundCastingCalls;
	}
	@GetMapping ("/messages/sent/{sender}")
	public List<Message> getSender(@PathVariable ("sender")String sender) {
		return messages.findMessageBySender(sender);
	}
	
	@GetMapping("/messages/{receiver}")
	public List<Message> getReceiver(@PathVariable("receiver")String receiver){
		return messages.findMessageByReceiver(receiver);
		
	    
	}
	@PostMapping("/messages")
	public void sendMessages(@RequestBody Message newMessage) {
	   messages.save(newMessage);
	}
	@DeleteMapping("messages/{messageid}")
	public void deleteMessage(@PathVariable ("messageid")Long messageid,@RequestBody Message message) {
		messages.delete(message);
	}
	
}


