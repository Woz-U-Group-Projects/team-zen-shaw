package com.securewebapp;

import org.springframework.data.jpa.repository.JpaRepository;

public interface CastingCallRepository extends JpaRepository<CastingCall,Long> {
	CastingCall findByPostid(Long postid);
	CastingCall findAllByStateAndCity(String state,String city);

}
