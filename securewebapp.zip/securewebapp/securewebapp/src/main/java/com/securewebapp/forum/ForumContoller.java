package com.securewebapp.forum;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;

import com.securewebapp.image.Image;
import com.securewebapp.image.ImageRepository;

public class ForumContoller {

    @Autowired
    private PostsRepository posts;
    
    @Autowired
    private MessageRepository messages;
    @Autowired
    private ImageRepository images;

	
	@GetMapping("/image/{user_id}/{isProfilePic}")
	public Image getImage(@PathVariable("user_id") Long userid,@PathVariable ("isProfilePic") Boolean isProfilePic){
		Image foundImage = images.findByuseridAndIsProfilePic(userid, isProfilePic==true);
			return foundImage;
				
	}
	@GetMapping("/images/{user_id}/{image_id}={isProfilePic}")
		public List<Image> getImages(@PathVariable("user_id")String userid,@PathVariable("image_id")Long imageid, @PathVariable ("isProfilePic")Boolean isProfilePic){
			List<Image> foundImages=images.findByisProfilePic(isProfilePic==false);
			return foundImages;
		}
		
	
	
	@GetMapping("/casting_calls")
	public List<CastingCall> getPosts(){
		List<CastingCall> foundPosts = posts.findAll();
		return foundPosts;
	}
	
	@GetMapping("/casting_call/{id}")
	public ResponseEntity <CastingCall> getPost(@PathVariable("id") Long postid){
		CastingCall foundPost = posts.findById(postid).orElse(null);
		
		if(foundPost==null) {
			return ResponseEntity.notFound().header("Message", "Nothing found with that id").build();
		}
		return ResponseEntity.ok(foundPost);
	
	}
	@GetMapping("casting_calls/{state}/{city}")
	public CastingCall getCastingCall(@PathVariable("state")String state,@PathVariable("city")String city){
		CastingCall foundCastingCalls=posts.findAllByStateAndCity(state, city);
		return foundCastingCalls;
	}
	
	@GetMapping("/casting_call/{id}/messages")
	public  ResponseEntity <Message> getMessages(Long postid){
		Message foundMessages=messages.findById(postid).orElse(null);
	if (foundMessages==null) {
		return ResponseEntity.notFound().header("Message", "No posts yet").build();
	}
	return ResponseEntity.ok(foundMessages);
}
	@PostMapping("/casting_call")
	public ResponseEntity<CastingCall> postMessage(@RequestBody CastingCall post){
		CastingCall createdPost=posts.save(post);
		return ResponseEntity.ok(createdPost);
		
	}
	@PostMapping("/messages")
	public ResponseEntity<Message> postMessage(@RequestBody Message message) {
		Message createdMessage=messages.save(message);
		return ResponseEntity.ok(createdMessage);
	}
	@PostMapping("/images")
	public ResponseEntity <Image> postMessage (@RequestBody Image image){
		Image createdImage= images.save(image);
		return ResponseEntity.ok(createdImage);
	}
}

}
