package com.securewebapp;




import javax.persistence.*;



@Entity
@Table(name="Message")

public class Message {	
	
		@Id
		@GeneratedValue(strategy= GenerationType.SEQUENCE)
		@Column(name = "id", updatable = false)
		private long messageid;
		
		private String receiver;
		
		private String sender;
		
		private String subject;
		
		private String message_text;

		public long getMessageid() {
			return messageid;
		}

		public void setMessageid(long messageid) {
			this.messageid = messageid;
		}

		public String getSubject() {
			return subject;
		}

		public void setSubject(String subject) {
			this.subject = subject;
		}

		public String getMessage_text() {
			return message_text;
		}

		public void setMessage_text(String message_text) {
			this.message_text = message_text;
		}

		public long getMessage_id() {
			return messageid;
		}

		public void setMessage_id(long messageid) {
			this.messageid = messageid;
		}

		public String getReceiver() {
			return receiver;
		}

		public void setReciever(String receiver) {
			this.receiver = receiver;
		}

		public String getSender() {
			return sender;
		}

		public void setSender(String sender) {
			this.sender = sender;
		}

	
}


