package com.securewebapp;



import java.text.SimpleDateFormat;
import java.util.Date;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.Table;



@Entity
@Table(name="CastingCalls")
public class CastingCall {
	

		private String username;
		
		@Id
		@GeneratedValue(strategy = GenerationType.SEQUENCE)
		@Column(name = "id", updatable = false)
		private Long postid;
		
		@Column(name="jobName")
		private String jobName;
		@Column(name="jobDescription")
		private String jobDescription;
		
		private String country;
		
		 private String city;
		 
		 private String state;
		
		 private Date date;
		
		public String getUsername() {
			return username;
		}
		public void setUsername(String username) {
			this.username = username;
		}
		public Long getPostid() {
			return postid;
		}
		public void setPostid(Long postid) {
			this.postid = postid;
		}
		
		
		public String getJobName() {
			return jobName;
		}
		public void setJobName(String jobName) {
			this.jobName = jobName;
		}
		public String getJobDescription() {
			return jobDescription;
		}
		public void setJobDescription(String jobDescription) {
			this.jobDescription = jobDescription;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public Date getDate() {
			return date;
		}
		public void setDate(Date date) {
			  this.date = date;
		}		
		
		
		
	}

