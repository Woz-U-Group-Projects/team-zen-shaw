package com.securewebapp.auth;


import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.securewebapp.forum.CastingCall;
import com.securewebapp.forum.Message;

@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name = "User")

public class User {

	@Id
	@GeneratedValue(strategy = GenerationType.SEQUENCE)
	@Column(name = "id", updatable = false, nullable = false)
	private Long userid;

	@Column(name = "firstName", nullable = false)
	private String firstName;

	@Column(name = "lastName", nullable = false)
	private String lastName;

	@Column(name = "username", nullable = false, unique = true)
	private String username;

	@Column(name = "password", nullable = false)
	private String password;

	@Column(name = "occupation")
	private String occupation;
	
	@Column(name="email", nullable=false, unique=true)
	private String email;
	
	@Column(name= "bio", nullable=false)
	private String bio;

	@OneToMany(fetch= FetchType.LAZY,cascade = CascadeType.ALL, mappedBy = "userid")
	private List<CastingCall> castingCall;

	@OneToMany(fetch= FetchType.LAZY,cascade = CascadeType.ALL, mappedBy = "userid")
	private List<Message> message;


	public List<CastingCall> getPost() {
		return castingCall;
	}

	public void setPost(List<CastingCall> castingCall) {
		this.castingCall = castingCall;
	}

	public List<Message> getMessage() {
		return message;
	}

	public void setMessage(List<Message> message) {
		this.message = message;
	}
	public String getFirstName() {
		return firstName;
	}

	public void setFirstName(String firstName) {
		this.firstName = firstName;
	}

	public String getLastName() {
		return lastName;
	}

	public void setLastName(String lastName) {
		this.lastName = lastName;
	}

	public String getUsername() {
		return username;
	}

	public void setUsername(String username) {
		this.username = username;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getOccupation() {
		return occupation;
	}

	public void setOccupation(String occupation) {
		this.occupation = occupation;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getBio() {
		return bio;
	}

	public void setBio(String bio) {
		this.bio = bio;
	}

}
