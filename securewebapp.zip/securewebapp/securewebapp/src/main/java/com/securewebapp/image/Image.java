package com.securewebapp.image;

import javax.persistence.*;

import com.fasterxml.jackson.annotation.JsonProperty;
import com.securewebapp.auth.User;
import com.securewebapp.forum.CastingCall;
import com.securewebapp.forum.Message;

@Entity
@Table(name="Image")
public class Image {
	 @Id
	 @GeneratedValue(strategy = GenerationType.AUTO)
	 public long imageid;
	 
	 @Column (name = "picture")
	    @Lob @JsonProperty("image")
	    private byte[] image;
	 @ManyToOne
	 @JoinColumn( name="FK_user_id")
	 	private User userid;
	 @ManyToOne
	 @JoinColumn(name="FK_post_id")
	 	private CastingCall postid;
	
	@ManyToOne
	 @JoinColumn( name="FK_message_id")
	 	private Message messageid;
	 
	 	private boolean isProfilePic;
	    
		public byte[] getImage()  {
	    	return image;
	    }
	    public void setImage (byte[] image) {
	    	this.image = image;
	    }
		
		 public User getUser_id() {
			return userid;
		}
		public void setUser_id(User userid) {
			this.userid = userid;
		}
		public CastingCall getPost_id() {
			return postid;
		}
		public void setPost_id(CastingCall postid) {
			this.postid = postid;
		}
		public Message getMessage_id() {
			return messageid;
		}
		public void setMessage_id(Message messageid) {
			this.messageid = messageid;
		}
		public boolean isProfilePic() {
				return isProfilePic;
		}
		public void setProfilePic(boolean isProfilePic) {
				this.isProfilePic = isProfilePic;
		}

}
