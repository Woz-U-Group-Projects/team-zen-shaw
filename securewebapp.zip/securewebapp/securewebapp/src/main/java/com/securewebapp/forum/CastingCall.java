package com.securewebapp.forum;



import java.util.Date;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.EntityListeners;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.OneToMany;
import javax.persistence.Table;

import org.hibernate.id.SequenceIdentityGenerator.Delegate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import com.securewebapp.auth.User;
@Entity
@EntityListeners(AuditingEntityListener.class)
@Table(name="Post")
public class CastingCall {
		
		@Id
		@GeneratedValue(strategy = GenerationType.AUTO)
		private Long postid;
		
		@ManyToOne
		@JoinColumn(name="FK_User_id")
		private User userid;
		
		@ManyToOne
		@JoinColumn (name="FK_Username")
		private User username;
		
		private String job_name;
		
		private String job_description;
		
		private String country;
		
		 private String city;
		 
		 private String state;
		
		 private Date date;
		
		@OneToMany(fetch= FetchType.LAZY,cascade = CascadeType.ALL, mappedBy = "postid")
		private List<Message> message;
		
		
		public Long getPostid() {
			return postid;
		}
		public void setPostid(Long postid) {
			this.postid = postid;
		}
		public User getUserid() {
			return userid;
		}
		public void setUserid(User userid) {
			this.userid = userid;
		}
		public String getJob_name() {
			return job_name;
		}
		public void setJob_name(String job_name) {
			this.job_name = job_name;
		}
		public String getJob_description() {
			return job_description;
		}
		public void setJob_description(String job_description) {
			this.job_description = job_description;
		}
		public String getCountry() {
			return country;
		}
		public void setCountry(String country) {
			this.country = country;
		}
		public String getCity() {
			return city;
		}
		public void setCity(String city) {
			this.city = city;
		}
		public String getState() {
			return state;
		}
		public void setState(String state) {
			this.state = state;
		}
		public Date getDate() {
			return date;
		}
		public void setDate(Date date) {
			this.date = date;
		}
		
		
		
		
	}

