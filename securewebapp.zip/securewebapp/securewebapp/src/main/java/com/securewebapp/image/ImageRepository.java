package com.securewebapp.image;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;

public interface ImageRepository extends JpaRepository<Image, Long> {
	@Query
	Image findByuseridAndIsProfilePic(Long user_id, Boolean isProfilePic);
	@Query
	List<Image> findByisProfilePic(Boolean isProfilePic);
	

}
